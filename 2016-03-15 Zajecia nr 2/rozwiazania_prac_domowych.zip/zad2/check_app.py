# -*- coding: utf-8 -*-
import requests
import hashlib
import time
import os
import sys
import unicodecsv as csv
from difflib import SequenceMatcher

from bs4 import BeautifulSoup, SoupStrainer
from collections import OrderedDict
from lxml import html

from barkowski_maciej.app import Fundusz
from przywarty_adam.bankierLogic import *
from cudzilo_tomasz.funds import scrape, print_to_csv
from siankiewicz_kamil.app import (
    getExchangeTableBody,
    getFundsExchange,
    saveCSVDataWithHeaders,
)

EXACT_CHECK = False
TIMEIT_MULTIPLIER = 2
URL = 'http://www.bankier.pl/fundusze/notowania/wszystkie'
HEADERS = (
    u'Nazwa funduszu',
    u'Kurs',
    u'Waluta',
    u'St. zw. 1D',
    u'St. zw. 7D',
    u'St. zw. 1M',
    u'St. zw. 3M',
    u'St. zw. 1R',
    u'St. zw. 3L',
    u'Data',
    u'Ranking 12M',
)


def timeit(method):

    def timed(*args, **kw):
        times = list()
        for i in xrange(TIMEIT_MULTIPLIER):
            ts = time.time()
            method(*args, **kw)
            te = time.time()
            times.append((te - ts))

        times.sort()
        return 'av: {} s, top: {} s'.format(
            '%2.2f' % (reduce(lambda x, y: x+y, times) / TIMEIT_MULTIPLIER),
            '%2.2f' % times[0])
    return timed

response = requests.get(URL)
response.encoding = 'utf-8'


@timeit
def antek(response, filename):
    # Przeparsujemy treść strony
    # parse the contents as a HTML
    soup = BeautifulSoup(response.text, 'html.parser')

    # mozna tez data = []
    # ale konwencja sugeruje tego nie robic jesli lista ma byc pusta
    data = list()

    # Wybieramy interesujące informacje z tabeli notowań
    # look for tables with specified class. Take the first one (0-based
    # indices).
    tabela = soup.find_all('table', class_="sortTableMixedData")[0]
    # take the data from one row at a time
    for wiersz in tabela.find_all('tr'):
        # we will extract the row data into this dictionary
        tmp_dict = OrderedDict()
        # tmp_dict = {
        #    "stopa 1M": '1,23%',
        #    "stopa 3M": '5,00%',
        #    ...
        # }
        # recursive=False means: don't look for nested td's
        komorki = wiersz.find_all('td', recursive=False)
        # zip(['a','b','c'], [666, 'X', -13]) ==  [('a',666), ('b','X'), ('c',-13)]
        # -> ("stopa 1M", '1,23%'), ...
        for naglowek, komorka in zip(HEADERS, komorki):
            # "    \n costam \n \t " -> "costam"
            tmp_dict[naglowek] = komorka.text.strip()
        data.append(tmp_dict)  # add just processed row to our resulting list

    # Wypisujemy te informacje do pliku csv
    # wypisz nazwy kolumn
    plik = open(filename, 'wb')

    # that's the guy that knows how to translate python objects to csv files
    writer = csv.writer(plik, encoding='utf-8')
    writer.writerow(HEADERS)  # the headers have to be written manually

    for wiersz in data:  # take each computed row
        # {'a': 5, 13: 'lol'}.values() == (5, 'lol')
        writer.writerow(wiersz.values())

    # we have to close the file handler to make sure that the write buffer is
    # flushed
    plik.close()


@timeit
def webster58(response, filename):
    index1 = response.text.find('<tbody')
    index2 = response.text.find('</tbody>', index1)
    soup = BeautifulSoup(response.text[index1:index2], 'lxml')

    def func(r):
        return map(lambda x: x.get('data-value', x.text),
                   r.find_all('td', recursive=0))

    trs = soup.find('tbody').find_all('tr', recursive=0)

    with open(filename, 'wb') as f:
        w = csv.writer(f, encoding='utf-8')
        w.writerow(HEADERS)
        w.writerows(map(func, filter(lambda x: x.attrs.get('class') is None, trs)))

@timeit
def antoniak_jan(response, filename):
    # parse the contents as a HTML
    soup = BeautifulSoup(response.text, 'html.parser')

    data = list()

    tabela = soup.find_all('tbody')[0]
    for wiersz in tabela.find_all('tr'):
        if not wiersz.has_attr('class'):
            tmp_dict = OrderedDict()

            komorki = wiersz.find_all('td', recursive=False)

            for naglowek, komorka in zip(HEADERS, komorki):
                tmp_dict[naglowek] = komorka.text.strip()
            tmp_dict['Ranking 12M'] = komorka.attrs['data-value']
            data.append(tmp_dict)

    plik = open(filename, 'wb')

    writer = csv.writer(plik, encoding='utf-8')
    writer.writerow(HEADERS)

    for wiersz in data:
        writer.writerow(wiersz.values())

    plik.close()


@timeit
def puchalski_pawel(response, filename):

    tree = html.fromstring(response.text)  # Parse the html

    data = zip(*([tree.xpath("//td/a/text()")] +
                 [tree.xpath("//td[position() mod 10 = %s]/text()" % (i)) for i in xrange(2, 10)] +
                 [tree.xpath("//td[position() mod 10 = 0]/text()")] +
                 [tree.xpath("//td/@data-value")]
                 ))

    f = open(filename, 'wb')
    w = csv.writer(f, encoding='utf-8')
    w.writerow(HEADERS)
    w.writerows(data)
    f.close()


@timeit
def barkowski_maciej(response, filename):
    Fundusz(htmlDoc=response, filename=filename)


@timeit
def klimaszewska_marta(response, filename):

    soup = BeautifulSoup(response.text, 'html.parser')
    data = list()
    tabela = soup.find_all('tbody')[0]

    for wiersz in tabela.find_all('tr', class_=None):

        komorki = wiersz.find_all('td', recursive=False)
        komorki = [komorka.get_text()
                   for komorka in komorki]

        rating = wiersz.find_all(attrs={'data-value': True})[0]['data-value']
        komorki[-1] = rating if rating != '0' else '0'

        data.append(OrderedDict(zip(HEADERS, komorki)))

    plik = open(filename, 'wb')
    writer = csv.DictWriter(plik, fieldnames=HEADERS, encoding='utf-8')
    writer.writeheader()
    writer.writerows(data)
    plik.close()


@timeit
def kochanksa_paula(response, filename):
    soup = BeautifulSoup(response.text, 'html.parser')
    data = list()

    # Wybieramy interesujące informacje z tabeli
    tbody = (soup.find_all('table', class_="sortTableMixedData")[0]).find_all(
        'tbody')[0]
    for wiersz in tbody.find_all('tr'):
        # dlaczego nie działa 'adv staticRow'?
        if wiersz.has_attr('class') and wiersz['class'][0] == 'adv':
            continue
        tmp_dict = OrderedDict()  # gwarantuje zachowanie kolejnosci
        komorki = wiersz.find_all('td', recursive=False)
        # łączenie w pary -> ("stopa 1M", "1,23")
        for naglowek, komorka in zip(HEADERS, komorki):
            if naglowek == 'Ranking 12M' and komorka['data-value'][0] != '0':
                tmp_dict[naglowek] = komorka['data-value'][0]
            else:
                # wyrzuca białe znaki
                tmp_dict[naglowek] = komorka.text.strip()
        data.append(tmp_dict)

    # Wypisujemy informacje do pliku csv
    plik = open(filename, 'wb')
    writer = csv.writer(plik, encoding='utf-8')
    writer.writerow(HEADERS)

    for wiersz in data:
        writer.writerow(wiersz.values())

    plik.close()


@timeit
def konat_kamil(response, filename):

    def get_site(url, encoding='utf-8'):

        html_doc = requests.get(URL)
        html_doc.encoding = encoding

        return html_doc

    def get_header(document, switch="on", class_=[u'colKurs', u'textNowrap']):
        tmp_list = list()
        if switch == "on":
            tmp_data = document.table.tr.find_all("th", recursive=False)
            for header in tmp_data:
                if header['class'] == class_:
                    tmp_list.append(
                        header.contents[0] + " " + header.contents[1].contents[0])
                else:
                    tmp_list.append(header.contents[0])
        else:
            tmp_list = (
                u'Nazwa funduszu',
                u'Kurs',
                u'Waluta',
                u'St. zw. 1D',
                u'St. zw. 7D',
                u'St. zw. 1M',
                u'St. zw. 3M',
                u'St. zw. 1R',
                u'St. zw. 3L',
                u'Data',
                u'Ranking 12M'
            )
        return tmp_list

    def get_data(document, header):
        tmp_list = list()
        row_list = list()
        hed_leng = len(header)
        itr = int(0)
        tmp_data = document.table.find_all("td")

        for data in tmp_data:

            if data.string is None and data.has_attr("data-value"):
                row_list.append(data["data-value"])
                itr += 1
            elif not data.string is None:
                row_list.append(data.string.strip())
                itr += 1

            if itr % (hed_leng) == 0:
                if row_list:
                    tmp_list.append(row_list)
                row_list = list()

        return tmp_list

    def write_data(dest, header, data, encoding="utf-8"):

        file_h = open(dest, "wb")
        writer = csv.writer(file_h, encoding=encoding)
        writer.writerow(header)
        for line in data:
            writer.writerow(line)
        file_h.close()

    document = BeautifulSoup(response.text, 'html.parser')
    header = get_header(document, switch="on")
    data = get_data(document, header)
    dest = filename

    write_data(dest, header, data)


@timeit
def misiewicz_michal(response, filename):

    # Parsowanie samej tabeli
    text = response.text
    start = text.find('<table')
    end = text.find('</table', start)
    # lxml jest szybszy niż zwykły parser html
    soup = BeautifulSoup(text[start:end], 'lxml')

    data = list()
    headers = list()

    table = soup.find_all('th')

    for column in table:
        index = column.text.find(' AD')
        headers.append(column.text[:index].strip())

    table = soup.find_all('tbody')[0]
    for row in table.find_all('tr', class_=""):
        tmp_dict = OrderedDict()

        cells = row.find_all('td', recursive=False)
        for column, cell in zip(headers, cells):
            if column != headers[len(headers) - 1]:
                tmp_dict[column] = cell.text.strip()
            else:
                tmp_dict[column] = cell["data-value"]
        data.append(tmp_dict)

    plik = open(filename, 'wb')

    writer = csv.writer(plik, encoding='utf-8')
    writer.writerow(headers)

    for row in data:
        writer.writerow(row.values())

    plik.close()


@timeit
def okuniewski_marcin(response, filename):
    data = list()

    table_beginning = response.text.find('<tbody')
    table_end = response.text.find('</tbody>')

    soup = BeautifulSoup(response.text[table_beginning:table_end], 'lxml')

    def cell_value(cell):
        if cell.get("data-value") != None:
            value = cell.get("data-value")
        else:
            value = cell.text.strip()
        return value

    for row in soup.find_all('tr', {'class': 'alt-row', 'class': ''}):
        temp_cells = [cell_value(cell)
                      for cell in row.find_all('td', recursive=False)]
        data.append(temp_cells)

    csv_file = open(filename, 'wb')
    writer = csv.writer(csv_file, encoding='utf-8')
    writer.writerow(HEADERS)
    for row in data:
        writer.writerow(row)
    csv_file.close()


@timeit
def pankowski_marek(response, filename):

    soup = BeautifulSoup(response.text, 'html.parser')
    data = list()
    tabela = soup.find_all('table', class_="sortTableMixedData")[0]
    for wiersz in tabela.find_all('tr', class_=not "adv staticRow"):
        tmp_dict = OrderedDict()
        wartosc = [item["data-value"]
                   for item in wiersz.find_all() if "data-value" in item.attrs]
        wartosc = str(wartosc).strip("[u']")
        wiersz.contents[-2].string = wartosc

        komorki = wiersz.find_all('td', recursive=False)
        for naglowek, komorka in zip(HEADERS, komorki):
            tmp_dict[naglowek] = komorka.text.strip()
        data.append(tmp_dict)

    plik = open(filename, 'wb')
    writer = csv.writer(plik, encoding='utf-8')
    writer.writerow(HEADERS)

    for wiersz in data:
        writer.writerow(wiersz.values())

    plik.close()


@timeit
def przywarty_adam(response, filename):

    row_data = list()
    nice_html_document = get_html(URL, response)
    headers = get_headers(get_html(URL, response))

    for row in nice_html_document.find_all('tr'):
        tmp_dict = OrderedDict()
        tmp_dict = populate_my_dict(row, tmp_dict, nice_html_document)
        row_data.append(tmp_dict)

    create_csv_file(headers, row_data, filename)


@timeit
def siankiewicz_kamil(response, filename):
    exchange_table_body = getExchangeTableBody(URL, response)
    exchanges = getFundsExchange(exchange_table_body)
    saveCSVDataWithHeaders(filename, HEADERS, exchanges)


@timeit
def stelmach_dawid(response, filename):

    HEADERS_SD = list()
    start = response.text.find('<table class="sortTableMixedData')
    stop = response.text.find('</table>', start)
    soup = BeautifulSoup(response.text[start:stop], "html.parser")
    table = soup.find_all('table', class_="sortTableMixedData")[0]
    data = list()

    thead = soup.find('thead')
    for row in thead.find_all('th'):
            if row.contents[1].contents[0] != 'A':
                HEADERS_SD.append(row.contents[0]+' '+row.contents[1].contents[0])
            else:
                HEADERS_SD.append(row.contents[0])

    for row in table.find_all('tr')[1:]:
        if not [u'adv', u'staticRow'] in row.attrs.viewvalues():
            tmp_list = list()
            cells = row.find_all('td')
            for cell in cells[0:10]:
                tmp_list.append(cell.text.strip())
            tmp_list.append(cells[10]['data-value'])
            data.append(tmp_list)

    plik = open(filename, 'wb')

    writer = unicodecsv.writer(plik, encoding='utf-8')
    writer.writerow(HEADERS_SD)
    writer.writerows(data)

    plik.close()


@timeit
def sykula_maciej(response, filename):

    data = list()

    soup = BeautifulSoup(response.text, 'html.parser')
    tabela = soup.find_all('table', class_='sortTableMixedData')[0]

    for wiersz in tabela.find_all('tr', class_=''):
        tmp_dict = OrderedDict()
        komorki = wiersz.find_all('td', recursive=False)
        for naglowek, komorka in zip(HEADERS, komorki):
            if naglowek == 'Ranking 12M':
                if str(filter(str.isdigit, str(komorka))) == '0':
                    tmp_dict['Ranking 12M'] = '-'
                else:
                    tmp_dict['Ranking 12M'] = str(filter(str.isdigit, str(komorka)))[1:]
            else:
                tmp_dict[naglowek] = komorka.text.strip()
        data.append(tmp_dict)

    plik = open(filename, 'wb')

    writer = csv.writer(plik, encoding='utf-8')

    writer.writerow(HEADERS)
    for wiersz in data:
        writer.writerow(wiersz.values())

    plik.close()


@timeit
def umanski_mikolaj(response, filename):
    with open(filename, 'wb') as csvfile:
        soup = BeautifulSoup(response.content, 'html.parser')

        fieldnames = [
            th.text.replace(' AD', '').splitlines()[0] for th in soup.find_all('th')
        ]

        writer = csv.writer(csvfile)

        writer.writerow(fieldnames)

        for tr in soup.find('tbody').find_all('tr', {'class': ''}):

            tds = tr.find_all('td')
            tds[-1].string = tds[-1].attrs.get('data-value')
            row = [td.text.strip() for td in tds]
            writer.writerow(row)


@timeit
def wadolkowski_adam(response, filename):
    def zapis():
        plik = open(filename, 'wb')
        writer = csv.writer(plik, encoding='utf-8')
        writer.writerow(HEADERS)
        for wiersz in data:
            writer.writerow(wiersz.values())
        plik.close()

    soup = BeautifulSoup(response.text, 'html.parser')
    data = list()

    tabela = soup.find_all('table', class_="sortTableMixedData")[0]

    for wiersz in tabela.find_all('tr', class_=""):
        tmp_dict = OrderedDict()
        komorki = wiersz.find_all('td', recursive=False)
        for naglowek, komorka in zip(HEADERS, komorki):
                if komorka.text.strip() != '':
                    tmp_dict[naglowek] = komorka.text.strip()
                else:
                    tmp_dict[naglowek] = komorka.get('data-value')
        data.append(tmp_dict)

    zapis()


@timeit
def zienko_marcin(response, filename):
    soup = BeautifulSoup(response.content, 'html.parser')

    headers = list()
    thead = soup.find_all('th')
    for th in thead:
        a = th.find_all('a')
        span = th.find_all('span')
        while len(a) > 0:
            for licznik in range(len(a)):
                th.a.decompose()
            break
        while len(span) > 0:
            for liczn in range(len(span)):
                th.span.decompose()
            break
        zmienna = th.text.strip()
        headers.append(zmienna)

    data = list()
    tabela = soup.find_all('table', class_="sortTableMixedData")[0]
    for wiersz in tabela.find_all('tr', class_=""):

        tmp_dict = OrderedDict()

        komorki = wiersz.find_all('td', recursive=False)

        for naglowek, komorka in zip(headers, komorki):
            tmp_dict[naglowek] = komorka.text.strip()
        data.append(tmp_dict)

    plik = open(filename, 'wb')

    writer = unicodecsv.writer(plik, encoding='utf-8')
    writer.writerow(headers)

    for wiersz in data:
        writer.writerow(wiersz.values())

    plik.close()


@timeit
def cudzilo_tomasz(response, filename):

    doctype, headers, rows = scrape(URL, response)
    print_to_csv(filename, headers, rows)


@timeit
def praca(response, filename):
    # Przeparsujemy treść strony
    # parse the contents as a HTML
    soup = BeautifulSoup(response.text, 'html.parser')

    # mozna tez data = []
    # ale konwencja sugeruje tego nie robic jesli lista ma byc pusta
    data = list()

    # Wybieramy interesujące informacje z tabeli notowań
    # look for tables with specified class. Take the first one (0-based
    # indices).
    tabela = soup.find_all('table', class_="sortTableMixedData")[0]
    # take the data from one row at a time
    for wiersz in tabela.find_all('tr'):
        # we will extract the row data into this dictionary
        tmp_dict = OrderedDict()
        # tmp_dict = {
        #    "stopa 1M": '1,23%',
        #    "stopa 3M": '5,00%',
        #    ...
        # }
        # recursive=False means: don't look for nested td's
        komorki = wiersz.find_all('td', recursive=False)
        # zip(['a','b','c'], [666, 'X', -13]) ==  [('a',666), ('b','X'), ('c',-13)]
        # -> ("stopa 1M", '1,23%'), ...
        for naglowek, komorka in zip(HEADERS, komorki):
            # "    \n costam \n \t " -> "costam"
            tmp_dict[naglowek] = komorka.text.strip()
        data.append(tmp_dict)  # add just processed row to our resulting list

    # Wypisujemy te informacje do pliku csv
    # wypisz nazwy kolumn
    plik = open(filename, 'wb')

    # that's the guy that knows how to translate python objects to csv files
    writer = csv.writer(plik, encoding='utf-8')
    writer.writerow(HEADERS)  # the headers have to be written manually

    for wiersz in data:  # take each computed row
        # {'a': 5, 13: 'lol'}.values() == (5, 'lol')
        writer.writerow(wiersz.values())

    # we have to close the file handler to make sure that the write buffer is
    # flushed
    plik.close()


reference_file = "reference.csv"
try:
    os.remove(reference_file)
except OSError:
    pass
webster58(response, reference_file)

original_md5 = hashlib.md5(open(reference_file, 'rb').read()).hexdigest()
original_file = open(reference_file).read()


def chceck_validity(filename, reference_md5):
    md5_data = False
    exact_data = 0

    with open(filename) as file_to_check:
        data = file_to_check.read()

        md5_data = reference_md5 == hashlib.md5(data).hexdigest()
        if EXACT_CHECK:
            if md5_data:
                exact_data = 100.0
            else:
                m = SequenceMatcher(None, original_file, data)
                exact_data = m.ratio() * 100.0

    return md5_data, exact_data

stats = list()


def run(name, comment=''):
    filename = '{}.csv'.format(name)
    try:
        os.remove(filename)
    except OSError:
        pass
    time = getattr(__import__('__main__'), name)(response, filename)
    validity, exactility = chceck_validity(filename, original_md5)
    txt = "\033[94m{}\033[0m - \033[{}\033[0m - \033[{}\033[0m - \033[1m{}\033[0m - \033[95m{}\033[0m".format(
        time,
        '92mvalid' if validity else '93minvalid',
        '{}{}%'.format(
            '92m' if exactility > 90.0 else '93m',
            '%2.4f' % exactility),
        name,
        comment)
    print txt
    stats.append(txt)


if __name__ == "__main__":

    if len(sys.argv) > 1:
        # adres możemy pobrać także z linii poleceń jako argument
        name = sys.argv[1]
        if len(sys.argv) > 2:
            TIMEIT_MULTIPLIER = int(sys.argv[2])
        if hasattr(__import__('__main__'), name):
            run(name, '')

    else:
        run('webster58', '\033[94mREFFERENCE\033[0m')
        run('antek', '\033[94mstan z zajec\033[0m')
        run('antoniak_jan', '-nieoptymalne')
        run('barkowski_maciej', '+podzial na klasy, +wartosci domyslme, +input line params, -nieoptymalne')
        run('cudzilo_tomasz', '+lxml, +parse_only, +podzial logiki na funkcje, +imap,ifilter, -list(imap(...))')
        run('klimaszewska_marta', '-"0" != "-" w ostaniej kolumnie, -nieoptymalne')
        run('kochanksa_paula', ' -nieoptymalne')
        run('konat_kamil', '+podzial na fukncję,  -nieoptymalne, --globals')
        run('misiewicz_michal', '+lxml, +przeczial wyszukiwania -inne hedery')
        run('okuniewski_marcin', '+lxml, +przedzial wyszukiwania, +filtrowanie elementow')
        run('pankowski_marek', '+filtrowanie po klasach')
        run('przywarty_adam', ' ... -czas wykonania ....')
        run('puchalski_pawel', '+lxml, +oneliner, +Najszybszy wynik!, -absoutnie nieczytelna dla nooba')
        run('siankiewicz_kamil', '')
        run('stelmach_dawid', '+zakresy wyszukiwania, +headers')
        run('sykula_maciej', '-nieptymalny, - mocno przekombinowane wyciągnie cyfry')
        run('umanski_mikolaj', '+with, +zapis lini w glownej petli, +filrowanie wyszukiwania')
        run('wadolkowski_adam', '-nieoptymalne')
        run('zienko_marcin', '-poziom skomplikowania,-nieoptymalne')

        os.system('clear')
        stats.sort()
        for stat in stats:
            print stat
