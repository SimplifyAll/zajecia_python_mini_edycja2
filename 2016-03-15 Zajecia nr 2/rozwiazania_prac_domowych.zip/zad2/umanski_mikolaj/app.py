

import requests
import unicodecsv
from bs4 import BeautifulSoup

url = 'http://www.bankier.pl/fundusze/notowania/wszystkie'

with open('wynik.csv', 'wb') as csvfile:
    r = requests.get(url)

    soup = BeautifulSoup(r.content, 'html.parser')

    fieldnames = [
        th.text.replace(' AD', '').splitlines()[0] for th in soup.find_all('th')
    ]

    writer = unicodecsv.writer(csvfile)

    writer.writerow(fieldnames)

    for tr in soup.find('tbody').find_all('tr', {'class': ''}):

        tds = tr.find_all('td')
        tds[-1].string = tds[-1].attrs.get('data-value')
        row = [td.text.strip() for td in tds]
        writer.writerow(row)
