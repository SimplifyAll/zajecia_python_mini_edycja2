#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
import unicodecsv


URL = "http://www.bankier.pl/fundusze/notowania/wszystkie"
HEADERS = list()
html_doc = requests.get(URL)
html_doc.encoding = 'utf-8'

start = html_doc.text.find('<table class="sortTableMixedData')
stop = html_doc.text.find('</table>', start)
soup = BeautifulSoup(html_doc.text[start:stop], "html.parser")
table = soup.find_all('table', class_="sortTableMixedData")[0]
data = list()

thead=soup.find('thead')
for row in thead.find_all('th'):
        if row.contents[1].contents[0]!='A':
            HEADERS.append(row.contents[0]+' '+row.contents[1].contents[0])
        else:
            HEADERS.append(row.contents[0])

for row in table.find_all('tr')[1:]:
    if not [u'adv', u'staticRow'] in row.attrs.viewvalues():
        tmp_list = list()
        cells = row.find_all('td')
        for cell in cells[0:10]:
        	tmp_list.append(cell.text.strip())
        tmp_list.append(cells[10]['data-value']) #w przypadku braku ratingu będzie "0" a nie '-' żeby nie trzeba było rozważać dwóch przypadków
        data.append(tmp_list)

plik = open('output_html.csv', 'wb')

writer = unicodecsv.writer(plik, encoding='utf-8')
writer.writerow(HEADERS)
writer.writerows(data)

plik.close()