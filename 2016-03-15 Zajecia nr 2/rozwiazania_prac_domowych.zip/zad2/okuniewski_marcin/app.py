#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests

import unicodecsv 

from bs4 import BeautifulSoup


URL = "http://www.bankier.pl/fundusze/notowania/wszystkie"  
HEADERS = (  
    u'Nazwa funduszu',  
    u'Kurs',
    u'Waluta',
    u'St. zw. 1D',
    u'St. zw. 7D',
    u'St. zw. 1M',
    u'St. zw. 3M',
    u'St. zw. 1R',
    u'St. zw. 3L',
    u'Data',
    u'Ranking 12M',
)


response = requests.get(URL)  
response.encoding = 'utf-8'

data = list()

table_beginning = response.text.find('<tbody')
table_end = response.text.find('</tbody>')

soup = BeautifulSoup(response.text[table_beginning:table_end], 'lxml')

def cell_value(cell):
    if cell.get("data-value") != None:
        value = cell.get("data-value")
    else:
        value = cell.text.strip()
    return value
    
    
for row in soup.find_all('tr',{'class':'alt-row','class':''}):
    temp_cells=[cell_value(cell) for cell in row.find_all('td',recursive=False)]
    data.append(temp_cells)    
   

csv_file = open('wynik.csv', 'wb')
writer = unicodecsv.writer(csv_file, encoding='utf-8')
writer.writerow(HEADERS) 
for row in data: 
    writer.writerow(row)
csv_file.close()