# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import unicodecsv as csv
from datetime import datetime


startTime = datetime.now()

HEADERS = (
    u'Nazwa funduszu',
    u'Kurs',
    u'Waluta',
    u'St. zw. 1D',
    u'St. zw. 7D',
    u'St. zw. 1M',
    u'St. zw. 3M',
    u'St. zw. 1R',
    u'St. zw. 3L',
    u'Data',
    u'Ranking 12M',
)

response = requests.get('http://www.bankier.pl/fundusze/notowania/wszystkie')
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'lxml')


def func(r):
    return map(lambda x: x.get('data-value', x.text).strip(),
               r.find_all('td', recursive=0))

trs = soup.find('tbody').find_all('tr', recursive=0)

with open('results.csv', 'wb') as f:
    w = csv.writer(f, encoding='utf-8')
    w.writerow(HEADERS)
    w.writerows(map(func, filter(lambda x: x.attrs.get('class') is None, trs)))

print datetime.now() - startTime
