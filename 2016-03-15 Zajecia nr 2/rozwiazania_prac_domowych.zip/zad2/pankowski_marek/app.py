#!/usr/bin/env python
# -*- coding: utf-8 -*-

from collections import OrderedDict
import unicodecsv
import requests
from bs4 import BeautifulSoup

URL = "http://www.bankier.pl/fundusze/notowania/wszystkie"
HEADERS = (
    u'Nazwa funduszu',
    u'Kurs',
    u'Waluta',
    u'St. zw. 1D',
    u'St. zw. 7D',
    u'St. zw. 1M',
    u'St. zw. 3M',
    u'St. zw. 1R',
    u'St. zw. 3L',
    u'Data',
    u'Ranking 12M',
)

#Pobieramy stronę z internetu
html_doc = requests.get(URL)
html_doc.encoding = 'utf-8'

#Przeparsujemy treść strony
soup = BeautifulSoup(html_doc.text, 'html.parser')
data = list()

#Wybieramy interesujące informacje z tabeli notowań
tabela = soup.find_all('table', class_="sortTableMixedData")[0]


for wiersz in tabela.find_all('tr', class_= not "adv staticRow"): #Usunięcie wszystkich pustych wierszy, które spełniały rolę miejsca na reklamy
    tmp_dict = OrderedDict()

    #Wyszukiwanie we wszystkich wierszach obiektu data-value i jej wartości
    wartosc = [item["data-value"] for item in wiersz.find_all() if "data-value" in item.attrs]

    #Wartość data-value zamieniamy na stringa i usuwamy z niego potrzebne znaki
    wartosc = str(wartosc).strip("[u']")

    #wrzucenie stringa w odpowiednie miejsce we wierszu, między znacznikami
    wiersz.contents[-2].string = wartosc

    komorki = wiersz.find_all('td', recursive=False)
    for naglowek, komorka in zip(HEADERS, komorki):
        tmp_dict[naglowek] = komorka.text.strip()
    data.append(tmp_dict)

# Wypisujemy te informacje do pliku csv
plik = open('wynik.csv', 'wb')
writer = unicodecsv.writer(plik, encoding='utf-8')
writer.writerow(HEADERS)

for wiersz in data:
    writer.writerow(wiersz.values())

plik.close()
