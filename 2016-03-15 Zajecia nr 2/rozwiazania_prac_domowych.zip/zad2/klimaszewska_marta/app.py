#!/usr/bin/env python
#-*- coding: utf-8 -*-

#Marta Klimaszewska

from collections import OrderedDict

import requests
from bs4 import BeautifulSoup
import unicodecsv

URL = "http://www.bankier.pl/fundusze/notowania/wszystkie"

HEADERS = (
	u'Nazwa funduszu', #u can hold ąęćżł
	u'Kurs',
	u'Waluta',
	u'St. zw. 1D',
	u'St. zw. 7D',
	u'St. zw. 1M',
	u'St. zw. 3M',
	u'St. zw. 1R',
	u'St. zw. 3L',
	u'Data',
	u'Ranking 12M',
) 

# pobieranie strony z internetu

html_doc = requests.get(URL)
html_doc.encoding = 'utf-8'

#print html_doc.text

# przeparsowanie treści strony

soup = BeautifulSoup(html_doc.text, 'html.parser')

# to samo co data = [], kwestia konwencji
data = list()

# wybieranie interesujących informacji z tabeli notowań

#tab = soup.find_all('table', class_="sortTableMixedData")[0]
#pierwszy pusty wiersz dlatego, że nie był w stanie zapisać theader

tabela = soup.find_all('tbody')[0]  #tylko jedno tbody na stronie

for wiersz in tabela.find_all('tr', class_=None): #eliminuje "adv staticRow"
	#tmp_dict = OrderedDict()
	komorki = wiersz.find_all('td', recursive=False) #tworzy listę składającą się ze wszystkich komórek
	komorki = [komorka.get_text() for komorka in komorki] #wyciąga sam tekst z komórek
	rating = wiersz.find_all(attrs={'data-value':True})[0]['data-value'] #słownik bo data-* nie działają normalnie
	komorki[-1] = rating if rating != '0' else '-'
	#tmp_dict[naglowek] = komorka.text.strip()
	data.append(OrderedDict(zip(HEADERS, komorki))) #zip na dwóch listach


# wypisanie informacji do pliku csv
# wypisanie nazw kolumn

plik = open('wynik.csv', 'wb')   #wb do zapisywania niestandardowych znaków

writer = unicodecsv.DictWriter(plik, fieldnames=HEADERS, encoding='utf-8') #DictWriter lepszy dla słowników

writer.writeheader() #wypisuje klucze

# for wiersz in data:

writer.writerows(data) #wypisuje wartości bez pętli 

plik.close()