#!/usr/bin/env python
# -*- encoding: utf-8 -*-

from collections import OrderedDict
from itertools import cycle, ifilter, imap, izip

import requests
from bs4 import BeautifulSoup, SoupStrainer, Tag
import unicodecsv

INPUT = 'http://www.bankier.pl/fundusze/notowania/wszystkie'
OUTPUT = 'funds.csv'

HEADER_CUTOUT = '  A D'
IGNORE_SELECTOR = "tr.staticRow"


def is_a_tag(cell):
    return isinstance(cell, Tag)


def extract_header(cell):
    return cell.get_text(' ').split(HEADER_CUTOUT)[0]


def extract_headers(row):
    return list(imap(extract_header, ifilter(is_a_tag, row.children)))
    # return [extract_header(cell) for cell in row.children if
    # isinstance(cell, Tag)]


def extract_value(cell):
    if cell.has_attr('data-value'):
        return cell['data-value']
    else:
        return cell.text.strip()


def extract_values(rows):
    return (imap(extract_value, ifilter(is_a_tag, row.children)) for row in rows)


def scrape(url, document=None):
    if not document:
        document = requests.get(url)
        document.encoding = 'utf-8'
    html = document.text
    # Read and parse only the relevant part of HTML
    soup = BeautifulSoup(
        html, 'lxml', parse_only=SoupStrainer('tr'), from_encoding='utf-8')
    # Get rid of the empty rows
    for empty_row in soup.select(IGNORE_SELECTOR):
        empty_row.decompose()
    # Prepare the iterator chain
    all_rows = soup.children
    # Discard the first child of BeautifulSoup-parsed document
    doctype = unicode(next(all_rows))
    # Manually load and read the table's headers
    headers = extract_headers(next(all_rows))
    # Create a chain of utitility iterators reading from the remaining <tr>
    # tags
    values = extract_values(all_rows)
    return doctype, headers, values


def print_to_csv(filename, headers, rows):
    csv_file = open(filename, 'wb')
    csv_writer = unicodecsv.writer(csv_file, encoding='utf-8')
    csv_writer.writerow(headers)
    csv_writer.writerows(rows)
    csv_file.close()

if __name__ == "__main__":
    doctype, headers, rows = scrape(INPUT)
    print_to_csv(OUTPUT, headers, rows)
