Udało się uzyskać ok. 38% krótszy czas pracy skryptu po następujących zmianach:
1. Używam parsera `lxml` napisanego w kodzie natywnym co znacząco skraca czas parsowania.
1. Podczas tworzenia obiektu `BeautifulSoup`, przekazuję do konstruktora `SoupStrainer`, który wymusza parsowanie tylko części ściągniętego dokumentu HTML.
1. Narzucam z góry kodowanie znaków parsowanego dokumentu, co pozwala na etap zgadywania kodowania.
1. W żadnym momencie działania skryptu, nie jest zapisana w pamięci pełna lista sprasowanych wartości. Jest to uzyskane poprzez stworzenie pipeline'u iteratorów przechodzących po iteratorze dzieci załadowanego obiektu `BeautifulSoup`.

Nie udało mi się zmniejszyć ilości kodu. Natomiast, na pewno, jest on bardziej czytelny.

Problem pustych linii został rozwiązany poprzez usunięcie ze sparsowanego drzewa obiektu `BeautifulSoup`, elementów z klasą `.staticRow`, które powodowały błędne wpisy w pliku CSV.

Wartości do ostatniej kolumny pliku CSV są odczytywane z atrybutu `data-value` z tagów komórek tabeli z dokumentu HTML.
