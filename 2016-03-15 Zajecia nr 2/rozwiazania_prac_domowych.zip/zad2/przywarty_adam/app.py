#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from bs4 import BeautifulSoup
from bankierLogic import *

URL = "http://www.bankier.pl/fundusze/notowania/wszystkie"
row_data = list()

nice_html_document = get_html(URL)
headers = get_headers(get_html(URL))

for row in nice_html_document.find_all('tr'):
	tmp_dict = OrderedDict()
	tmp_dict = populate_my_dict(row, tmp_dict, nice_html_document)
	row_data.append(tmp_dict)

create_csv_file(headers, row_data)