import unicodecsv
import requests
from bs4 import BeautifulSoup


def get_html(url, html_doc=None):
    if html_doc is None:
        html_doc = requests.get(url)
        html_doc.encoding = 'utf-8'

    soup = BeautifulSoup(html_doc.text, 'html.parser')
    soup_array_result = soup.find_all('table', class_="sortTableMixedData")[0]
    clear_soup = remove_ads(soup_array_result)
    return clear_soup


def remove_ads(soup):
    for ad in soup.find_all('tr', class_="adv"):
        ad.replaceWith('')
    return soup


def get_headers(soup_array_result):
    head = list()

    def clear_head(head):
        for span_tag in head.find_all('span'):
            span_tag.replace_with('')
        for a_tag in head.find_all('a'):
            a_tag.replace_with('')
        return head
    for header in soup_array_result.find_all('thead'):
        header = clear_head(header)
        headers = header.find_all('th')
        for h in headers:
            head.append(h.text.strip())
    return head


def get12monthsranking(column):
    try:
        r12m = column.find('td', {'data-value': True})['data-value']
        return r12m
    except:
        pass


def populate_my_dict(row, tmp_dict, soup_array_result):
    columns = row.find_all('td', recursive=False)
    r12m = get12monthsranking(row)
    headers = get_headers(soup_array_result)
    for head, cell in zip(headers, columns):
        tmp_dict[head] = cell.text
    tmp_dict['Ranking12M'] = r12m
    return tmp_dict


def create_csv_file(headers, rows, filename='wynik.csv'):
    result_file = open(filename, 'wb')
    writer = unicodecsv.writer(result_file, encoding='utf-8')
    writer.writerow(headers)
    for row in rows:
        writer.writerow(row.values())
    result_file.close()
