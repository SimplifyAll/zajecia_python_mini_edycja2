#!/usr/bin/env python
# -*- coding: utf-8 -*-

from collections import OrderedDict
import time

import unicodecsv
import requests
from bs4 import BeautifulSoup


URL = 'http://www.bankier.pl/fundusze/notowania/wszystkie'
HEADERS = (
    u'Nazwa funduszu',
    u'Kurs',
    u'Waluta',
    u'St. zw. 1D',
    u'St. zw. 7D',
    u'St. zw. 1M',
    u'St. zw. 3M',
    u'St. zw. 1R',
    u'St. zw. 3L',
    u'Data',
    u'Ranking 12M',
)
html_doc = requests.get(URL)
html_doc.encoding = 'utf-8'

data = list()

soup = BeautifulSoup(html_doc.text, 'html.parser')
tabela = soup.find_all('table', class_='sortTableMixedData')[0]

for wiersz in tabela.find_all('tr', class_=''):
    tmp_dict = OrderedDict()
    komorki = wiersz.find_all('td', recursive=False)
    for naglowek, komorka in zip(HEADERS, komorki):
        if naglowek == 'Ranking 12M':
            if str(filter(str.isdigit, str(komorka))) == '0':
                tmp_dict['Ranking 12M'] = '-'
            else:
                tmp_dict['Ranking 12M'] = str(filter(str.isdigit, str(komorka)))[1:]
        else:
            tmp_dict[naglowek] = komorka.text.strip()
    data.append(tmp_dict)

plik = open('wynik.csv', 'wb')

writer = unicodecsv.writer(plik, encoding='utf-8')

writer.writerow(HEADERS)
for wiersz in data:
    writer.writerow(wiersz.values())

plik.close()
