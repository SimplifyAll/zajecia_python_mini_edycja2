#!/usr/bin/env python
#-*-coding: utf-8-*-
# plik fundusze2.py

import sys
from collections import OrderedDict

import unicodecsv
import requests
from bs4 import BeautifulSoup


class Fundusz:

    def __init__(self, adres=None, htmlDoc=None, filename='wynik1.csv'):

        if adres == None:
            self.URL = "http://www.bankier.pl/fundusze/notowania/wszystkie"
        else:
            self.URL = adres

        self.HEADERS = list()
        self.filename = filename
        if not htmlDoc:
            try:
                htmlDoc = requests.get(self.URL)
                htmlDoc.encoding = "utf-8"

            except requests.exceptions.RequestException as error:
                print "Wystąpił błąd %s" % error
                sys.exit(0)

        soup = BeautifulSoup(htmlDoc.text, "html.parser")
        self.table = soup.find_all("tbody")[0]
        self.tableHead = soup.find_all("thead")[0]
        self.head()

    # wyszukanie nazw w nagłówku: Nazwa funduszu, Kurs, Waluta itd..
    def head(self):

        for part in self.tableHead("tr"):
            komorkiNaglowka = part.find_all("th")
            for komorka in komorkiNaglowka:
                for a, znak in enumerate(komorka.get_text()):
                    if znak == "A":
                        self.HEADERS.append(komorka.get_text().strip()[:a])
                        break
        self.find()

    def find(self):

        data = list()
        for part in self.table.find_all("tr"):

            tempDict = OrderedDict()
            komorki = part.find_all("td")

            for naglowek, komorka in zip(self.HEADERS, komorki):

                if "data-value" in komorka.attrs:
                    if komorka["data-value"] != "0":
                        # dodaje do słownika rating zawarty w tagu img
                        tempDict[naglowek] = komorka["data-value"] + "A"

                else:
                    if ";" in komorka.get_text():
                        tempDict[naglowek] = komorka.get_text().strip().replace(
                            ";", "")  # usuwa dodatkowy średnik
                    else:
                        tempDict[naglowek] = komorka.get_text().strip()

            # dodaje słownik do listy tylko wtedy jeśli wielkość słownika > 1
            if len(tempDict) > 1:
                data.append(tempDict)

        self.writeToCsv(data)

    def writeToCsv(self, data):

        plik = open(self.filename, "wb")

        wr = unicodecsv.writer(plik, encoding="utf-8")
        wr.writerow(self.HEADERS)
        [wr.writerow(wiersz.values()) for wiersz in data]

        plik.close()

if __name__ == "__main__":

    if len(sys.argv) > 1:
        # adres możemy pobrać także z linii poleceń jako argument
        fundusze = Fundusz(sys.argv[1])
    else:
        fundusze = Fundusz()
