#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unicodecsv
import requests
from bs4 import BeautifulSoup

def get_site(url, encoding='utf-8'):
    """
    Funkcja pobierająca stronę internetową.\n
    Przyjmuje argumenty:
    \turl      -adres URL strony internetowej, którą chcemy pobrać
    \tencoding -kodowanie strony internetowej, domyślna wartość "utf-8"\n
    Zwraca pobraną stronę internetową w postaci obiektu klasy Response.
    """

    html_doc = requests.get(URL)
    html_doc.encoding = encoding

    return html_doc

def get_header(document, switch="on", class_= [u'colKurs', u'textNowrap']):
    """
    Funkcja wczytująca nagłówek.\n
    Przyjmuje argumenty:
    \tdocument -dokument, obiekt kalsy BeautifulSoup,
    \tswitch   -argument z domyślną wartością "on", jeżeli jest ona "włączona"
    \t\tto funkcja przeszukuje podany dokument w celu znalezienia aktualnego
    \t\tnagłówka jeżeli jest "wyłączony" to funkcja zwraca domyślny nagłówek
    \tclass_   -argument z domyślną wartością "[u'colKurs', u'textNowrap']
    \t\t przy jego pomocy możemy określić klasy jakie mają być brane pod uwagę
    \t\t przy wyborze pól nagłówka.\n
    Zwraca nagłówek w postaci listy.
    """    

    tmp_list = list()
    
    if switch=="on":

        tmp_data = document.table.tr.find_all("th", recursive=False)

        for header in tmp_data:
    
            if header['class'] == class_:
                tmp_list.append(header.contents[0] + " " + header.contents[1].contents[0])
        
            else: 
                tmp_list.append(header.contents[0])
    
    else:

        tmp_list = (
                u'Nazwa funduszu',
                u'Kurs',
                u'Waluta',
                u'St. zw. 1D',
                u'St. zw. 7D',
                u'St. zw. 1M',
                u'St. zw. 3M',
                u'St. zw. 1R',
                u'St. zw. 3L',
                u'Data',
                u'Ranking 12M'
                )

    return tmp_list

def get_data(document, header):
    """
    Funkcja przetwarzająca kod HTML.\n
    Przyjmuje argumenty:
    \tdocument -dokument, obiekt klasy BeautifulSoup,
    \theader   -nagłówek, obiket klasy List, który będzie wprowadzony do pliku CSV.\n
    Zwraca przetworzony kod html nadający się do zapisu w pliku CSV,
    w postaci listy list:
    [[],[],...].
    """
    
    tmp_list = list()
    row_list = list()
    hed_leng = len(header)
    itr = int(0)
    tmp_data = document.table.find_all("td")
    
    for data in tmp_data:
        
        if data.string is None and data.has_attr("data-value"):
            row_list.append(data["data-value"])
            itr += 1
        
        elif not data.string is None:
            row_list.append(data.string.strip())
            itr += 1
        
        if itr % (hed_leng) == 0:
            if row_list:
                tmp_list.append(row_list)
            row_list = list()
    
    return tmp_list

def write_data(dest, encoding="utf-8"):
    """
    Funkcja zapisująca przetworzone dane do pliku.\n
    Przyjmuje argumenty:
    \tdest     -nazwa pliku w którym mają zostać zapisane przetworzone dane,
    \tencoding -argument z domyślną wartością "utf-8", do określenia kodowania
    \t\tpliku docelowego.\n
    Nie zwraca żadnej wartości.
    """ 

    file_h = open(dest, "wb")
    writer = unicodecsv.writer(file_h, encoding=encoding)
    writer.writerow(header)
    for line in data:
        writer.writerow(line)
    file_h.close()

if __name__ == "__main__":

    import sys

    URL      = "http://www.bankier.pl/fundusze/notowania/wszystkie"
    html_doc = get_site(URL)
    document = BeautifulSoup(html_doc.text, 'html.parser')
    header   = get_header(document, switch="on")
    data     = get_data(document, header)
    dest     = "wynik.csv"

    if len(sys.argv) > 1:
        dest = str(sys.argv[1])

    write_data(dest)
