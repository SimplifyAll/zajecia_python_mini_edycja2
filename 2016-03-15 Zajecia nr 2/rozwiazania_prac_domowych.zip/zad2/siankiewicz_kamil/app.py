#!/usr/bin/env python
# -*- coding: utf-8 -*-

from collections import OrderedDict
import sys
import re

from bs4 import BeautifulSoup
import requests
import unicodecsv

URL = 'http://www.bankier.pl/fundusze/notowania/wszystkie'
RANK_HEADER_NAME = u'Ranking 12M'
HEADERS = (
    u'Nazwa funduszu',
    u'Kurs',
    u'Waluta',
    u'St. zw. 1D',
    u'St. zw. 7D',
    u'St. zw. 1M',
    u'St. zw. 3M',
    u'St. zw. 1R',
    u'St. zw. 3L',
    u'Data',
    RANK_HEADER_NAME,
)


def getExchangeTableBody(url, html_doc=None):
    if html_doc is None:
        html_doc = requests.get(url)
        html_doc.encoding = 'utf-8'
    soup = BeautifulSoup(html_doc.text, 'html.parser')
    table = soup.find('table', class_='sortTableMixedData').find('tbody')
    return table


def getImageRating(cell):
    img = cell.find('img')
    if not img or not img.has_attr('src'):
        return None
    regex_matcher = re.search('(?<=/)(\d)(?=_mini)', img['src'])
    return regex_matcher.group(0)


def getFundDetails(row):
    fund_details = OrderedDict()
    cells = row.find_all('td', recursive=False)
    for header, cell in zip(HEADERS, cells):
        image_rating = None
        if (header == RANK_HEADER_NAME):
            image_rating = getImageRating(cell)
        fund_details[header] = image_rating or cell.text.strip()
    return fund_details


def getFundsExchange(table):
    data = list()
    for row in table.find_all('tr'):
        # skip advertisements
        if row.has_attr('class') and 'adv' in row['class']:
            continue

        fund_details = getFundDetails(row)
        data.append(fund_details)
    return data


def saveCSVDataWithHeaders(output_filename, headers, csv_data):
    output_csv = open(output_filename, 'wb')
    writer = unicodecsv.writer(output_csv, encoding='utf-8')
    writer.writerow(headers)
    for row in csv_data:
        writer.writerow(row.values())
    output_csv.close()


def printUsage():
    print 'usage: ' + sys.argv[0] + ' <output_file>'


def getCommandLineParameters():
    if len(sys.argv) >= 2:
        path = sys.argv[1].strip()
        if len(path) > 0:
            return path
    return None

if __name__ == '__main__':
    output_file = getCommandLineParameters()
    if output_file is None:
        printUsage()
        sys.exit(1)

    exchange_table_body = getExchangeTableBody(URL)
    exchanges = getFundsExchange(exchange_table_body)
    saveCSVDataWithHeaders(output_file, HEADERS, exchanges)
