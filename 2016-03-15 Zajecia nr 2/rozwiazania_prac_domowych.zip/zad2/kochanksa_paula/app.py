#!/usr/bin/env python
# -*- coding: utf-8 -*-

# importy standardowe
from collections import OrderedDict

# importy z innych bibliotek
import requests
import unicodecsv
from bs4 import BeautifulSoup

# Konwencja - drukowane litery to stałe
URL = "http://www.bankier.pl/fundusze/notowania/wszystkie"

# u informuje, ze znaki są w unicode
HEADERS = (
    u"Nazwa funduszu",
    u"Kurs",
    u"Waluta",
    u"Stopa zwrotu 1D",
    u"Stopa zwrotu 7D",
    u"Stopa zwrotu 1M",
    u"Stopa zwrotu 3M",
    u"Stopa zwrotu 1R",
    u"Stopa zwrotu 3L",
    u"Data",
    u"Ranking 12M",
)

# Pobieramy stronę z internetu
html_doc = requests.get(URL)
html_doc.encoding = "utf-8"

# Przeparsujemy treść strony
soup = BeautifulSoup(html_doc.text, 'html.parser')
data = list()

# Wybieramy interesujące informacje z tabeli
tbody = (soup.find_all('table', class_="sortTableMixedData")[0]).find_all(
    'tbody')[0]
for wiersz in tbody.find_all('tr'):
    # dlaczego nie działa 'adv staticRow'?
    if wiersz.has_attr('class') and wiersz['class'][0] == 'adv':
        continue
    tmp_dict = OrderedDict()  # gwarantuje zachowanie kolejnosci
    komorki = wiersz.find_all('td', recursive=False)
    # łączenie w pary -> ("stopa 1M", "1,23")
    for naglowek, komorka in zip(HEADERS, komorki):
        if naglowek == 'Ranking 12M' and komorka['data-value'][0] != '0':
            tmp_dict[naglowek] = komorka['data-value'][0]
        else:
            tmp_dict[naglowek] = komorka.text.strip()  # wyrzuca białe znaki
    data.append(tmp_dict)

# Wypisujemy informacje do pliku csv
plik = open('wynik.csv', 'wb')
writer = unicodecsv.writer(plik, encoding='utf-8')
writer.writerow(HEADERS)

for wiersz in data:
    writer.writerow(wiersz.values())

plik.close()
