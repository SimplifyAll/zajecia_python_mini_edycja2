#!/usr/bin/env python
# -*- coding: utf-8 -*-


import requests
from lxml import html
import unicodecsv as csv


FILENAME = 'results_lxml.csv'
URL = "http://www.bankier.pl/fundusze/notowania/wszystkie"
HEADERS = (
    u'Nazwa funduszu',
    u'Kurs',
    u'Waluta',
    u'St. zw. 1D',
    u'St. zw. 7D',
    u'St. zw. 1M',
    u'St. zw. 3M',
    u'St. zw. 1R',
    u'St. zw. 3L',
    u'Data',
    u'Ranking 12M',
)

response = requests.get(URL)
response.encoding = 'utf-8'

tree = html.fromstring(response.content)  # Parse the html

data = zip(*([tree.xpath("//td/a/text()")] +
             [tree.xpath("//td[position() mod 10 = %s]/text()" % (i)) for i in xrange(2, 10)] +
             [tree.xpath("//td[position() mod 10 = 0]/text()")] +
             [tree.xpath("//td/@data-value")]
             ))


f = open(FILENAME, 'wb')
w = csv.writer(f, encoding='utf-8')
w.writerow(HEADERS)
w.writerows(data)
f.close()
