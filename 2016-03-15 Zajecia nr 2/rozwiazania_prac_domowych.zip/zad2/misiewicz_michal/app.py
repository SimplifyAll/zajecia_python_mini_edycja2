#!/usr/bin/env python
# -*- coding: utf-8 -*-

#Autor: Michał Misiewicz

from collections import OrderedDict

import unicodecsv
import requests
from bs4 import BeautifulSoup

URL = "http://www.bankier.pl/fundusze/notowania/wszystkie"
FILENAME = "wynik_mm.csv"

html_doc = requests.get(URL)
html_doc.encoding = 'utf-8'

# Parsowanie samej tabeli
text = html_doc.text
start = text.find('<table')
end = text.find('</table', start)
# lxml jest szybszy niż zwykły parser html
soup = BeautifulSoup(text[start:end], 'lxml')

data = list()
headers = list()

table = soup.find_all('th')

for column in table:
	index = column.text.find(' AD')
	headers.append(column.text[:index].strip())

table = soup.find_all('tbody')[0]
for row in table.find_all('tr', class_=""):
	tmp_dict = OrderedDict()

	cells = row.find_all('td', recursive=False)
	for column, cell in zip(headers, cells):
		if column != headers[len(headers)-1]:
			tmp_dict[column] = cell.text.strip()
		else: tmp_dict[column] = cell["data-value"]
	data.append(tmp_dict)


plik = open(FILENAME,'wb')

writer = unicodecsv.writer(plik, encoding='utf-8')
writer.writerow(headers)

for row in data:
	writer.writerow(row.values())

plik.close()