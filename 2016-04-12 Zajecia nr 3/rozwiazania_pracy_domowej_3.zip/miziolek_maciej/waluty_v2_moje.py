#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Komentarze Maciej Miziołek

# Miałem problem z polskimi znakami w nazwie wykresu oraz opisach osi.
# Moduł pyplot biblioteki matplotlib nie akceptował czcionki Arial,
# nie była zainstalowana i używał domyślnej zwracając błąd
# UserWarning: findfont: Font family [u'Arial'] not found.
# Falling back to Bitstream Vera Sans
# (prop.get_family(), self.defaultFamily[fontext])).
# Konieczna była instalacja pakietu czcionek msttcorefonts
# (sudo apt-get install msttcorefonts) oraz wykasowanie
# zawartości cash biblioteki matplotlib
# (~/.cache/matplotlib/) w celu ich aktualizacji.


# Biblioteki wbudowane

import datetime

# Biblioteki zewnętrzne doinstalowane

import matplotlib.pyplot as plt  # we use it to plot the graphs
from matplotlib import rc  # we use it to change the default font configuration
import requests

# Sprawdzenie czy strona źródłowa jest dostępna


def url_ok(url):
    r = requests.head(url)
    return r.status_code == 200

# Wprowadzenie danych przez użytkownika


def wprowadz_dane():

    wejscie = 0

    while True:
        try:
            wejscie = int(input(
                "Proszę podać częstotliwość pobierania danych, np co 30 dni (domyślnie 15 dni): "))
        except ValueError:
            print(
                'Podane dane nie są prawidłowe. Proszę wprowadzić liczbę całkowitą większą od 0.')
            continue
        else:
            if wejscie < 1:
                print(
                    'Podane dane nie są prawidłowe. Proszę wprowadzić liczbę całkowitą większą od 0.')
            else:
                return wejscie


# pobieramy dane
def get_data(tick=30, base="PLN"):
    params = {'base': base, 'symbols': 'EUR,USD'}

    data = dict()  # mozna tez {}

    curr_date = datetime.date(year=2015, month=4, day=1)
    while curr_date <= datetime.date.today():
        resp = requests.get(
            'http://api.fixer.io/{}'.format(curr_date),
            params=params
        )
        resp_json = resp.json()
        # resp_json['rates'].items() = [(u'USD', 0.26485), (u'EUR', 0.24626)]
        for waluta, wartosc in resp_json['rates'].items():
            if waluta not in data.keys():  # to sie odpali tylko raz
                data[waluta] = {
                    'argumenty': list(),
                    'wartosci': list(),
                }
            data[waluta]['argumenty'].append(curr_date)
            data[waluta]['wartosci'].append(wartosc)
        curr_date = curr_date + datetime.timedelta(days=tick)
    return data


# rysujemy dane na wykresie
def draw_graph(data):
    # domyslna czcionka Bitstream Vera Sans nie musi miec polskich znakow
    rc('font', family="Arial")

    linie = list()  # uzyjemy tego do dopasowania linii wykresu do legendy
    waluty = list()  # uzyjemy tego do poprawnego oznaczenia walut w legendzie
    # Dolna granica przedziału czasowego, dla którego pobierane są dane
    data_pocz = data['USD']['argumenty'][0]
    # Górna granica przedziału czasowego, dla którego pobierane są dane
    data_kon = data['USD']['argumenty'][len(data['USD']['argumenty']) - 1]
    for waluta, dane in data.items():
        # plt.plot() zwraca liste wyrysowanych obiektow, interesuje nas zerowy
        linia = plt.plot(dane['argumenty'], dane['wartosci'])[0]
        waluty.append(waluta)
        linie.append(linia)

    plt.legend(linie, waluty)  # linie i waluty sa w tej samej kolejnosci
    plt.xlabel(u"Czas")
    plt.ylabel(u"Wartości")
    plt.title(u"Miziolek Maciej - Nasz piękny wykres PLN / {waluta_1}, PLN / {waluta_2} z okresu {data_1} - {data_2}"
              .format(waluta_1=waluty[0], waluta_2=waluty[1], data_1=data_pocz, data_2=data_kon))
    plt.show()  # dopiero teraz nasz wykres pojawi sie na ekranie

DELTA_CZAS = wprowadz_dane()
# Domyślnie jest 15, ale tu nadpisujemy jako wartość podaną przez użytkownika
dane = get_data(tick=DELTA_CZAS)

url_ok('http://api.fixer.io')
draw_graph(dane)



###########################################################
# NAJPROSTRZE
# 1) przekazanie parametrów: OK, parsowalne w trakci wykonania
# 2) parsowanie dat: FAIL
#
# PROSTE
# 1) DefaultDicty: FAIL
# 2) Klasa: FAIL
#
# UMIARKOWANE
# 1) przybliżanie wartości: FAIL
# 2) przewidywanie przyszłości: FAIL
#
# Z GWIAZDKĄ
# 1) sprawdzanie czy strona fixer.io działa
###########################################################
# KOMENTARZ
###########################################################
# 1) 
# 