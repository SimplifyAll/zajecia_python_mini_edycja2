#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Autor: Michał Misiewicz

import datetime
from collections import defaultdict

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import rc
import requests
import numpy as np


def get_data(tick=30, base="PLN", symbols='EUR,USD'):
    params = {'base': base, 'symbols': symbols}
    data = dict()

    for waluta in symbols.split(','):
        data[waluta] = defaultdict(list)

    curr_date = datetime.date(year=2015, month=4, day=1)

    while curr_date <= datetime.date.today():
        resp = requests.get(
            'http://api.fixer.io/{}'.format(curr_date), params=params)
        resp_json = resp.json()
        for waluta, wartosc in resp_json['rates'].items():
            date = datetime.datetime.strptime(resp.json()['date'], '%Y-%m-%d')
            data[waluta]['argumenty'].append(date)
            data[waluta]['wartosci'].append(wartosc)

        curr_date = curr_date + datetime.timedelta(days=tick)

    return data


def draw_graph(data, steps=3, poly_n=3, tick=14):
    rc('font', family="Arial")

    linie = list()
    waluty = list()
    legend_titles = list()

    if steps > 0:
        key = data.keys()[0]
        daty = list(data[key]['argumenty'])
        for i in xrange(steps):
            daty.append(daty[-1] + datetime.timedelta(tick))

    for waluta, dane in data.items():
        linia = plt.plot(dane['argumenty'], dane['wartosci'], '-o')[0]
        linie.append(linia)
        legend_titles.append(waluta)
        if steps > 0:
            x = mdates.date2num(dane['argumenty'])
            model = np.polyfit(x, dane['wartosci'], poly_n)
            x = mdates.date2num(daty)
            prediction = np.polyval(model, x)
            linia = plt.plot(daty, prediction, 'o-')[0]
            linie.append(linia)
            legend_titles.append('Prognoza dla {}'.format(waluta))

    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%d-%m-%Y'))
    plt.legend(linie, legend_titles)
    plt.xlabel("Czas")
    plt.ylabel(u"Wartości")
    plt.title(u"Misiewicz Michał - Nasz piękny wykres")
    plt.show()


if __name__ == '__main__':
    dane = get_data(14)
    draw_graph(dane)



###########################################################
# NAJPROSTRZE
# 1) przekazanie parametrów: FAIL,
# 2) parsowanie dat: OK
#
# PROSTE
# 1) DefaultDicty: OK
# 2) Klasa: FAIL
#
# UMIARKOWANE
# 1) przybliżanie wartości: OK, polifit, bardzo eleganckie
# 2) przewidywanie przyszłości: OK, ok polyval
#
# Z GWIAZDKĄ
# 1) Date formatter
###########################################################
# KOMENTARZ
###########################################################
# 1) 
# 