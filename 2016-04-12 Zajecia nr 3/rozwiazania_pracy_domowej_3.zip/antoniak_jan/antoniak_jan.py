#!/usr/bin/env python
# -*- coding: utf-8 -*-
import datetime as dt
from datetime import datetime

import matplotlib.pyplot as plt  # we use it to plot the graphs
from matplotlib import rc  # we use it to change the default font configuration
import requests


# pobieramy dane
def get_data(tick=30, base="PLN", symbols="EUR,USD"):
    params = {'base': base, 'symbols': symbols}
    # komentarz (1)
    symbols_list = list()
    symbols_list = symbols.split(',')

    data = dict()
    for i in symbols_list:                # data structure defined earlier
        data[i] = dict()
        data[i]['argumenty'] = list()
        data[i]['wartosci'] = list()

    curr_date = dt.date(year=2015, month=4, day=1)
    while curr_date <= dt.date.today():
        resp = requests.get(
            'http://api.fixer.io/{}'.format(curr_date),
            params=params
        )
        resp_json = resp.json()
        # resp_json['rates'].items() = [(u'USD', 0.26485), (u'EUR', 0.24626)]
        for waluta, wartosc in resp_json['rates'].items():
            # if waluta not in data.keys():  # to sie odpali tylko raz    #This part of code is not needed anymore
            #    data[waluta] = {
            #        'argumenty': list(),
            #        'wartosci': list(),
            #    }

            # original date taken from json data
            original_date = datetime.strptime(
                str(resp_json.get('date')), '%Y-%m-%d').date()
            data[waluta]['argumenty'].append(original_date)
            data[waluta]['wartosci'].append(wartosc)
        curr_date = curr_date + dt.timedelta(days=tick)
    return data


# rysujemy dane na wykresie
def draw_graph(data):
    # domyslna czcionka Bitstream Vera Sans nie musi miec polskich znakow
    rc('font', family="Arial")

    linie = list()  # uzyjemy tego do dopasowania linii wykresu do legendy
    waluty = list()  # uzyjemy tego do poprawnego oznaczenia walut w legendzie
    for waluta, dane in data.items():
        # plt.plot() zwraca liste wyrysowanych obiektow, interesuje nas zerowy
        linia = plt.plot(dane['argumenty'], dane['wartosci'])[0]
        waluty.append(waluta)
        linie.append(linia)

    plt.legend(linie, waluty)  # linie i waluty sa w tej samej kolejnosci
    plt.xlabel(u"Czas")
    plt.ylabel(u"Wartości")
    plt.title(u"Antoniak Jan - Nasz piękny wykres")
    plt.show()  # dopiero teraz nasz wykres pojawi sie na ekranie


if __name__ == "__main__":

    dane = get_data(tick=7, symbols="EUR,USD")

    draw_graph(dane)

###########################################################
# NAJPROSTRZE
# 1) przekazanie parametrów: OK
# 2) parsowanie dat: OK
#
# PROSTE
# 1) DefaultDicty: FAIL
# 2) Klasa: FAIL
#
# UMIARKOWANE
# 1) przybliżanie wartości: FAIL
# 2) przewidywanie przyszłości: FAIL
#
# Z GWIAZDKĄ
# 1) FAIL
###########################################################
# KOMENTARZ
###########################################################
# 1) split() zwraca listę, nie trzeba jej tworzyć od zera
# 