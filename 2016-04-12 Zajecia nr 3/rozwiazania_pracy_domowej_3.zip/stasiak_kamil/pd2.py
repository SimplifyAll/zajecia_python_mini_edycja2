#!/usr/bin/env python
# -*- coding: utf-8 -*-
import datetime
import collections

import requests
import matplotlib.pyplot as plt
from matplotlib import rc
import matplotlib.dates as mdates
import numpy as np


def get_data(tick=30, base="PLN", symbols="EUR,USD"):

    # pobierany dane

    data = collections.defaultdict(lambda: collections.defaultdict(list))
    params = {'base': base, 'symbols': symbols}

    curr_date = datetime.date(year=2015, month=4, day=1)
    while curr_date <= datetime.date.today():
        resp = requests.get(
            # 2000-01-03 laczenei stringow + jest wolne i pamiecizerne
            'http://api.fixer.io/{}'.format(curr_date),
            # 'http://api.fixer.io/{data}'.format(data=curr_date),
            params=params
        )
        resp_json = resp.json()  # [(u'USD', 0.42342),(u'EUR',0.3423)]
        pobrana_data = datetime.datetime.strptime(
            resp_json['date'], "%Y-%m-%d").date()
        for waluta, wartosc in resp_json['rates'].items():

            data[waluta]['argumenty'].append(pobrana_data)
            data[waluta]['wartosci'].append(wartosc)

        curr_date = curr_date + datetime.timedelta(days=tick)
    return data

# rysujemt dane na wykresie


def draw_graph(data, l_interwalow=1, stopien_wielomianu=3):
    #rc('font', family="Arial")
    linie = list()
    waluty = list()
    for waluta, dane in data.items():
        x = dane['argumenty']
        y = dane['wartosci']
        linia = plt.plot(x, y, 'o')[0]
        # LINIA TRENDU:
        x2 = mdates.date2num(x)
        z = np.polyfit(x2, y, stopien_wielomianu)
        p = np.poly1d(z)

        interwal = x[1] - x[0]
        for i in xrange(l_interwalow):
            x.append(x[-1] + interwal)
        x2 = mdates.date2num(x)
        plt.plot(x, p(x2), 'r--')

        waluty.append(waluta)
        linie.append(linia)

    plt.legend(linie, waluty)
    plt.xlabel("czas")
    plt.ylabel(u"wartości")
    plt.title(u"Stasiak Kamil - Nasz piękny wykres")
    plt.show()

dane = get_data(tick=100)

draw_graph(dane, 2)


###########################################################
# NAJPROSTRZE
# 1) przekazanie parametrów: OK, parsowalne w trakci wykonania
# 2) parsowanie dat: FAIL
#
# PROSTE
# 1) DefaultDicty: FAIL
# 2) Klasa: FAIL
#
# UMIARKOWANE
# 1) przybliżanie wartości: OK
# 2) przewidywanie przyszłości: OK
#
# Z GWIAZDKĄ
# 1) FAIL
###########################################################
# KOMENTARZ
###########################################################
# 1) ?? Gdzie linie wykresu ???
# 