#!/usr/bin/env python
#-*-coding: utf-8-*-
# plik waluty1.py

import datetime
import sys
import locale
from collections import defaultdict

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import requests


class Waluty:

    # konstruktor pobiera datę, walutę bazową i ewentualnie pozostałe waluty
    def __init__(self, *args):

        if len(args) == 0:
            year = 2016
            month = 3
            day = 1
            self.walutaBaz = "PLN"
            self.waluta = "EUR"
        else:
            year = args[0]
            month = args[1]
            day = args[2]
            self.walutaBaz = args[3]
            self.waluta = ""
            for arg in args[4:]:
                self.waluta += "%s," % arg
            self.waluta = self.waluta[:-1]

        params = {"base": self.walutaBaz, "symbols": self.waluta}

        curr_date = datetime.date(int(year), int(month), int(day))
        self.begDate = curr_date

        # nazwy miesięcy na wykresie po polsku
        locale.setlocale(locale.LC_TIME, "pl_PL.utf8")

        data = self.getData(params, curr_date, 1)
        self.drawGraph(data)

    def getData(self, params, curr_date, tick=30):

        data = defaultdict(lambda: insideDict)

        try:
            while curr_date <= datetime.date.today():

                resp = requests.get(
                    "http://api.fixer.io/{}".format(curr_date),
                    params=params
                )
                resp_json = resp.json()

                # porównanie daty dla której żądamy kursu, z datą zwracaną przez API,
                # jeżeli data różna tzn. że tego dnia nie był notowany kurs

                if str(resp_json["date"]) != str(curr_date):
                    curr_date = curr_date + datetime.timedelta(days=1)
                    continue

                for waluta, wartosc in resp_json["rates"].items():
                    insideDict = {"argumenty": list(), "wartosci": list()}
                    data[waluta]["argumenty"].append(curr_date)
                    data[waluta]["wartosci"].append(wartosc)

                curr_date = curr_date + datetime.timedelta(days=tick)

        except requests.exceptions.RequestException as error:
            print "Wystąpił błąd %s", error

        return data

    def drawGraph(self, data):

        print data

        linie = list()
        waluty = list()

        for waluta, dane in data.items():
            linia = plt.plot(dane["argumenty"], dane["wartosci"])[0]
            waluty.append(waluta)
            linie.append(linia)

        plt.legend(linie, waluty)
        plt.xlabel(u"Czas")
        plt.ylabel(u"Wartości")
        plt.title(u"Barkowski Maciej - Wykres kursów walut %s w odniesieniu do waluty bazowej %s od dnia %s do dzisiaj" % (
            str(self.waluta), str(self.walutaBaz), str(self.begDate)
        ))

        # dodanie linii trendu - funkcja liniowa

        # konwersja dat do formatu odpowiedniego dla funkcji polyfit
        datyNum = mdates.date2num(dane["argumenty"])
        trendDict = dict()  # słownik {waluta:trend}

        # uzupełnienie słownika {waluta:trend}
        for waluta, dane in data.items():
            trend = np.polyfit(datyNum, dane["wartosci"], 1)
            trendDict[waluta] = trend

        for waluta in trendDict:
            val = np.poly1d(trendDict[waluta])
            x = np.linspace(datyNum.min(), datyNum.max(), 100)
            # konwersja z formatu funkcji polyfit do formatu daty
            datyDat = mdates.num2date(x)
            t = plt.plot(datyDat, val(x), "g")[0]

        plt.show()

if __name__ == "__main__":

    if len(sys.argv[1:]) >= 5:
        waluty = Waluty(*sys.argv[1:])
    else:
        print "domyślne parametry:\ndata rozpoczęcia: 2016-3-1\nwaluta bazowa: PLN\nwaluta kursu: EUR\n"
        print "można wprowadzić inne parametry w formacie: rok miesiąc dzień, waluta bazowa, waluty kursu\n"
        waluty = Waluty(url='asd.com')
        waluty.getData()
        waluty.processData()
        waluty.showGraph()




###########################################################
# NAJPROSTRZE
# 1) przekazanie parametrów: OK ... nie do końca idealnie ale lepiej niż potrzeba
# 2) parsowanie dat: FAIL
#
# PROSTE
# 1) DefaultDicty: WHAAAAT ??? no niby tak się da ale należy to przemyśleć !
# 2) Klasa: OK, problem w tym że klasa nie różni się od funkcji
#           storzenie obiektu klasy wywoułe całą logikę aplikacji :/
#
# UMIARKOWANE
# 1) przybliżanie wartości: OK
# 2) przewidywanie przyszłości: FAIL
#
# Z GWIAZDKĄ
# 1) Podawanie danych z lini poleceń, OK ale niestety muszą być wszystkie i to posortowane.
#    Nie ma niestety walidacji pól.
###########################################################
# KOMENTARZ
###########################################################
