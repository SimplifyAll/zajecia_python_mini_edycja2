#!/usr/bin/env python
# -*- coding: utf-8 -*-

import datetime
from collections import defaultdict
import numpy as np

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import rc
import requests

# pobieramy dane


def get_data(tick=30, base="PLN", symbols="EUR,USD", future=3):

    params = {'base': base, 'symbols': symbols}
    data = defaultdict(list)

    curr_date = datetime.date(year=2015, month=4, day=1)
    while curr_date <= datetime.date.today() + datetime.timedelta(days=future * 30):
        resp = requests.get(
            'http://api.fixer.io/{}'.format(curr_date),
            params=params
        )
        resp_json = resp.json()
        for waluta, wartosc in resp_json['rates'].items():
            if waluta not in data.keys():
                data[waluta] = {
                    'argumenty': list(),
                    'wartosci': list(),
                }
            date_export = datetime.datetime.strptime(
                resp_json['date'], '%Y-%m-%d').date()
            # domyślnie argumentem jest date_export, ale z nim nie da się
            data[waluta]['argumenty'].append(curr_date)
            # wyświetlać lini trendu 'w przyszłość'
            data[waluta]['wartosci'].append(wartosc)
        curr_date = curr_date + datetime.timedelta(days=tick)
    return data


# rysujemy dane na wykresie

def draw_graph(data, wielomian=3):
    linie = list()
    waluty = list()
    x = list()
    y = list()
    for waluta, dane in data.items():
        linia = plt.plot(dane['argumenty'], dane['wartosci'])[0]
        waluty.append(waluta)
        linie.append(linia)

        x = mdates.date2num(dane['argumenty'])
        # z = np.polyfit(x, dane['wartosci'], 1) #linie trendu - funkcje
        # liniowe
        z = np.polyfit(x, dane['wartosci'], wielomian)
        p = np.poly1d(z)
        plt.plot(x, p(x))

    plt.legend(linie, waluty)
    plt.xlabel(u"Czas")
    plt.ylabel(u"Wartości")
    plt.title(u"Sykula Maciej - Nasz piękny wykres")
    plt.show()


dane = get_data()
draw_graph(dane)



###########################################################
# NAJPROSTRZE
# 1) przekazanie parametrów: FAIL
# 2) parsowanie dat: OK
#
# PROSTE
# 1) DefaultDicty: OK
# 2) Klasa: FAIL
#
# UMIARKOWANE
# 1) przybliżanie wartości: ~OK, dane wejściowe są zaburzone przes ostatnie 3 wartości.
# 2) przewidywanie przyszłości: ~OK, ostatnie wartości mają tę samą wartość
#
# Z GWIAZDKĄ
# 1) FAIL
###########################################################
# KOMENTARZ
###########################################################
# 