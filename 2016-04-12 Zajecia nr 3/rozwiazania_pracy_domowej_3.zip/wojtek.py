# -*- coding: utf-8 -*-

import datetime
import requests

import matplotlib.pyplot as plt
import matplotlib.dates as plot_date
import numpy
from collections import defaultdict



BASE_URL = u'http://api.fixer.io/{0}'


class customPlotData(object):

    def __init__(self):
        self.x = list()
        self.y = defaultdict(list)

    def addRawData(self, data):
        self.x.append(datetime.datetime.strptime(data['date'], "%Y-%m-%d"))
        for curr, rate in data['rates'].items():
            self.y[curr].append(rate)

    def getXaxis(self, predict=0, interval=None):
        if predict and interval:
            _x = self.x[:]
            for i in xrange(predict):
                _x.append(_x[-1]+interval)
            return _x
        return self.x

    def getData(self):
        for curr in self.y:
            yield self.x, self.y[curr]

    def getDataPredictions(self, predict=0, interval=None, deg=1):
        if predict and interval:
            _x_predict = self.getXaxis(predict, interval)
            _x_predict_n = plot_date.date2num(_x_predict)
            _x_n = plot_date.date2num(self.x)
            for curr in self.y:
                coefficients = numpy.polyfit(_x_n, self.y[curr], deg)
                equation = numpy.poly1d(coefficients)
                yield _x_predict, equation(_x_predict_n)

    def getCurrencies(self):
        return self.y.keys()


def gather_data(start_date, tick, base_cur='PLN', list_curr=['EUR', 'USD']):
    curr_date = start_date
    params = {
        'base': base_cur,
        'symbols': ','.join(list_curr),
    }

    today = datetime.date.today()
    data = customPlotData()

    while curr_date <= today:
        url = BASE_URL.format(curr_date)
        res = requests.get(url, params=params)
        data.addRawData(res.json())

        curr_date += tick
    return data


def show_graph(data, rotation=None, tick=None, deg=3):
    lines = list()
    # real data lines
    for x, y in data.getData():
        lines.append(plt.plot(x, y)[0])

    # approximation processing
    for x, y in data.getDataPredictions(predict=3, interval=tick, deg=3):
        lines.append(plt.plot(x, y)[0])

    plt.legend(lines, data.getCurrencies(), loc='upper right', shadow=True)

    if rotation:
        plt.xticks(rotation=rotation)
    plt.xlabel('time')
    plt.ylabel('val')
    plt.title('Wykres nas piekny')

    plt.show()

tick = datetime.timedelta(days=14)
data = gather_data(
    start_date=datetime.date(year=2015, month=1, day=1),
    tick=tick,
    base_cur='PLN',
    list_curr=['EUR', 'USD'],
)
show_graph(data, rotation=45, tick=tick, deg=3)
