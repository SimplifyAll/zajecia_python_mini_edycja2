#!/usr/bin/env python
#-*- coding: utf-8 -*-

# Marta Klimaszewska

import datetime  # wbudowana
import sys
from collections import defaultdict

import requests  # doinstalowana
import matplotlib.pyplot as plt
from matplotlib import rc

# pobieranie danych


def get_data(tick=30, base="PLN"):
    params = {'base': str(base), 'symbols': 'EUR,USD'}

    data = {}	# komentarz (1)

    curr_date = datetime.date(year=2015, month=4, day=1)

    while curr_date <= datetime.date.today():
        resp = requests.get(
            "http://api.fixer.io/{}".format(curr_date),  # 2000-01-03
            params=params
        )
        resp_json = resp.json()
        for waluta, wartosc in resp_json['rates'].items():
            if waluta not in data.keys():
                data[waluta] = defaultdict(list)
            data[waluta]['argumenty'].append(
                datetime.datetime.strptime(resp_json['date'], '%Y-%m-%d')
            )
            data[waluta]['wartosci'].append(wartosc)

        curr_date = curr_date + datetime.timedelta(days=int(tick))

    return data

# rysowanie danych na wykresie


def draw_graph(data):
    rc('font', family="Arial")  # font family Arial not found

    linie = []	# komentarz (1)
    waluty = []	# komentarz (1)
    for waluta, dane in data.items():
        linia = plt.plot(dane['argumenty'], dane['wartosci'])[0]
        waluty.append(waluta)
        linie.append(linia)

    plt.legend(linie, waluty)
    plt.xlabel(u"Czas")
    plt.ylabel(u"Wartości")
    plt.title(u'Klimaszewska Marta - Zmiany w kursach walut')
    plt.show()

dane = get_data(*sys.argv[1:])

draw_graph(dane)


###########################################################
# NAJPROSTRZE
# 1) przekazanie parametrów: OK z lini poleceń,
# 2) parsowanie dat: OK
#
# PROSTE
# 1) DefaultDicty: FAIL
# 2) Klasa: FAIL
#
# UMIARKOWANE
# 1) przybliżanie wartości: FAIL
# 2) przewidywanie przyszłości: FAIL
#
# Z GWIAZDKĄ
# 1) FAIL
###########################################################
# KOMENTARZ
###########################################################
# 1) zmiana deklaracji list() na [] lub dict() na {} nie była potrzebna
# 